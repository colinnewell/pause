package Jenkins::Hack;
our $VERSION = '0.13';
1
